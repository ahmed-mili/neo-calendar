import * as React from "react";
import { CalendarSource, DisplayEvent, ViewType } from "../types";
import MiniCalendar from "./MiniCalendar";
import {
    SidebarToggleIcon,
    SearchIcon,
    SettingsIcon,
    NewEventIcon,
    PlusIcon,
    RssIcon,
    EyeIcon,
    EyeOffIcon,
    MoreHorizontalIcon,
    PencilIcon,
    ListXIcon,
    ChevronDownIcon,
    FolderIcon,
    LinkIcon,
    CircleHelpIcon,
} from "./Icons";
import CalendarItemMenu, { CalendarMenuItem } from "./CalendarItemMenu";
import ColorPicker from "./ColorPicker";
import ShortcutsPanel from "./ShortcutsPanel";
import { ObsidianIcon } from "../components/ObsidianIcon";
import { useSidebarReorder } from "./useSidebarReorder";

const ONLINE_TYPES = ["ical", "caldav", "icloud"];

interface CalendarSidebarProps {
    sidebarVisible: boolean;
    currentDate: Date;
    viewType: ViewType;
    onViewTypeChange: (view: ViewType) => void;
    dayCount: number;
    onSetDayCount: (count: number) => void;
    calendarSources: CalendarSource[];
    firstDay: number;
    showWeekNumbers?: boolean;
    onDateSelect: (date: Date) => void;
    hiddenCalendars: Set<string>;
    onToggleCalendar: (calendarId: string) => void;
    defaultCalendarId: string;
    soloCalendarId: string | null;
    onSetDefaultCalendar: (calendarId: string) => void;
    onShowOnly: (calendarId: string) => void;
    somedayEvents: DisplayEvent[];
    onEventClick: (eventId: string) => void;
    onAddSomeday: () => void;
    onToggleTask: (eventId: string, isDone: boolean) => Promise<boolean>;
    onAddCalendar: () => void;
    onRenameCalendar: (calendarId: string, newName: string) => Promise<void>;
    onEditCalendarLink: (calendarId: string) => void;
    onDeleteCalendar: (calendarId: string) => void;
    onColorChange: (calendarId: string, color: string) => void;
    onReorderCalendars: (orderedIds: string[]) => void;
    onOpenCalendarFolder: (calendarId: string) => void;
    onOpenRootFolder: () => void;
    onCalendarClick: (calendarId: string) => void;
    selectedCalendarId: string | null;
    onToggleSidebar: () => void;
    onOpenSearch: () => void;
    onOpenSettings: () => void;
    onNewEvent: () => void;
}

export default function CalendarSidebar(props: CalendarSidebarProps) {
    const {
        sidebarVisible,
        currentDate,
        viewType,
        onViewTypeChange,
        dayCount,
        onSetDayCount,
        calendarSources,
        firstDay,
        showWeekNumbers,
        onDateSelect,
        hiddenCalendars,
        onToggleCalendar,
        defaultCalendarId,
        soloCalendarId,
        onSetDefaultCalendar,
        onShowOnly,
        onEventClick,
        onToggleTask,
        onAddCalendar,
        onRenameCalendar,
        onEditCalendarLink,
        onDeleteCalendar,
        onColorChange,
        onReorderCalendars,
        onOpenCalendarFolder,
        onOpenRootFolder,
        onCalendarClick,
        selectedCalendarId,
        onToggleSidebar,
        onOpenSearch,
        onOpenSettings,
        onNewEvent,
    } = props;

    const [editingId, setEditingId] = React.useState<string | null>(null);
    const [editName, setEditName] = React.useState("");
    const [renaming, setRenaming] = React.useState(false);
    const [menuId, setMenuId] = React.useState<string | null>(null);
    const [menuAnchor, setMenuAnchor] = React.useState<DOMRect | null>(null);
    // Anchor for the section-header "..." menu (Open root folder).
    const [headerMenuAnchor, setHeaderMenuAnchor] =
        React.useState<DOMRect | null>(null);
    // Collapse toggle for the calendar list (chevron next to the "Calendars"
    // header), mirroring Notion's collapsible section.
    const [calendarsCollapsed, setCalendarsCollapsed] = React.useState(false);
    // Custom themed colour picker (replaces the OS-native <input type=color">):
    // which calendar it's editing + where to anchor it (the clicked swatch).
    const [colorPicker, setColorPicker] = React.useState<{
        id: string;
        color: string;
        rect: DOMRect;
    } | null>(null);
    const [shortcutsAnchor, setShortcutsAnchor] =
        React.useState<DOMRect | null>(null);
    const [moreDaysOpen, setMoreDaysOpen] = React.useState(false);
    const [customDayCount, setCustomDayCount] = React.useState(10);
    const isAndroid =
        typeof document !== "undefined" &&
        document.body.classList.contains("nc-platform-android");

    const setAndroidDaySpan = (count: number) => {
        const normalized = Math.max(1, Math.min(60, Math.round(count)));
        onViewTypeChange("days");
        onSetDayCount(normalized);
        onToggleSidebar();
    };
    // Swatch button per calendar id, so the picker can anchor to it whether it
    // was opened by double-click or from the "Color" menu item.
    const swatchRefs = React.useRef<Record<string, HTMLButtonElement | null>>(
        {}
    );
    const openColorPicker = (id: string, color: string) => {
        const rect = swatchRefs.current[id]?.getBoundingClientRect();
        if (rect) setColorPicker({ id, color, rect });
    };

    // Drag-to-reorder the calendar list. On drop we translate the moved index
    // into the new full order of ids and hand it up to persist.
    const reorder = useSidebarReorder(calendarSources.length, (from, to) => {
        const ids = calendarSources.map((s) => s.id);
        const [moved] = ids.splice(from, 1);
        ids.splice(to, 0, moved);
        onReorderCalendars(ids);
    });

    const startRename = (source: CalendarSource) => {
        setEditingId(source.id);
        setEditName(source.name);
    };

    const commitRename = async () => {
        if (!editingId || !editName.trim()) {
            setEditingId(null);
            return;
        }
        const source = calendarSources.find((s) => s.id === editingId);
        if (source && editName.trim() !== source.name) {
            setRenaming(true);
            try {
                await onRenameCalendar(editingId, editName.trim());
            } finally {
                setRenaming(false);
            }
        }
        setEditingId(null);
    };

    const cancelRename = () => {
        setEditingId(null);
        setEditName("");
    };

    const openMenu = (e: React.MouseEvent, sourceId: string) => {
        setMenuAnchor(e.currentTarget.getBoundingClientRect());
        setMenuId(sourceId);
    };

    const buildMenuItems = (source: CalendarSource): CalendarMenuItem[] => {
        const items: CalendarMenuItem[] = [];
        items.push({
            key: "color",
            label: "Color",
            swatchColor: source.color,
            onClick: () => openColorPicker(source.id, source.color),
        });
        // Editable (local) calendars rename the folder; ical feeds rename just
        // sets a friendly display label â€” both go through the inline editor.
        if (source.editable || source.type === "ical") {
            items.push({
                key: "rename",
                label: "Rename",
                icon: <PencilIcon />,
                onClick: () => startRename(source),
            });
        }
        // Remote ical feeds can have their subscription URL changed in place.
        if (source.type === "ical") {
            items.push({
                key: "edit-link",
                label: "Edit link",
                icon: <LinkIcon />,
                onClick: () => onEditCalendarLink(source.id),
            });
        }
        if (source.type === "local") {
            items.push({
                key: "open-folder",
                label: "Open folder",
                icon: <FolderIcon />,
                onClick: () => onOpenCalendarFolder(source.id),
            });
        }
        items.push({
            key: "solo",
            label:
                soloCalendarId === source.id
                    ? "Show previously visible calendars"
                    : "Show only this calendar",
            icon: soloCalendarId === source.id ? <EyeIcon /> : <EyeOffIcon />,
            onClick: () => onShowOnly(source.id),
        });
        items.push({
            key: "remove",
            label: "Remove from list",
            icon: <ListXIcon />,
            danger: true,
            onClick: () => onDeleteCalendar(source.id),
        });
        return items;
    };

    const menuSource = menuId
        ? calendarSources.find((s) => s.id === menuId)
        : undefined;

    return (
        <div
            className={`nc-sidebar ${
                sidebarVisible ? "" : "nc-sidebar-collapsed"
            }`}
        >
            <div className="nc-sidebar-top-bar">
                <button
                    className="nc-sidebar-top-btn"
                    onClick={onToggleSidebar}
                    title="Toggle sidebar"
                >
                    <SidebarToggleIcon />
                </button>
                <div className="nc-sidebar-top-right">
                    <button
                        className="nc-sidebar-top-btn nc-sidebar-search-btn"
                        onClick={onOpenSearch}
                        title="Open command menu"
                    >
                        <SearchIcon />
                    </button>
                    <button
                        className="nc-sidebar-top-btn nc-sidebar-settings-btn"
                        onClick={onOpenSettings}
                        title="Settings"
                        aria-label="Settings"
                    >
                        <SettingsIcon size={17} />
                    </button>
                    <button
                        className="nc-sidebar-top-btn nc-sidebar-new-event-btn"
                        onClick={onNewEvent}
                        title="Create event"
                    >
                        <NewEventIcon />
                    </button>
                </div>
            </div>

            {sidebarVisible && (
                <>
                    {isAndroid && (
                        <section className="nc-android-day-switcher" aria-label="Days displayed">
                            <div className="nc-android-day-switcher-primary">
                                {[1, 2, 3].map((count) => {
                                    const active =
                                        viewType === "days" && dayCount === count;
                                    return (
                                        <button
                                            type="button"
                                            key={count}
                                            className={`nc-android-day-option${
                                                active ? " nc-active" : ""
                                            }`}
                                            aria-pressed={active}
                                            onClick={() => setAndroidDaySpan(count)}
                                        >
                                            <span className="nc-android-day-option-icon" aria-hidden="true">
                                                {Array.from({ length: count }, (_, index) => (
                                                    <i key={index} />
                                                ))}
                                            </span>
                                            <span>{count === 1 ? "1 day" : `${count} days`}</span>
                                        </button>
                                    );
                                })}
                            </div>

                            <button
                                type="button"
                                className="nc-android-more-days-toggle"
                                aria-expanded={moreDaysOpen}
                                onClick={() => setMoreDaysOpen((value) => !value)}
                            >
                                <span>More day spans</span>
                                <ChevronDownIcon size={14} />
                            </button>

                            {moreDaysOpen && (
                                <div className="nc-android-more-days">
                                    <div className="nc-android-more-days-grid">
                                        {[4, 5, 6, 7, 8, 9].map((count) => (
                                            <button
                                                type="button"
                                                key={count}
                                                className={
                                                    viewType === "days" && dayCount === count
                                                        ? "nc-active"
                                                        : ""
                                                }
                                                onClick={() => setAndroidDaySpan(count)}
                                            >
                                                {count}
                                            </button>
                                        ))}
                                    </div>
                                    <form
                                        className="nc-android-custom-days"
                                        onSubmit={(event) => {
                                            event.preventDefault();
                                            setAndroidDaySpan(customDayCount);
                                        }}
                                    >
                                        <input
                                            type="number"
                                            min={1}
                                            max={60}
                                            value={customDayCount}
                                            aria-label="Custom number of days"
                                            onChange={(event) =>
                                                setCustomDayCount(
                                                    Number(event.currentTarget.value) || 1
                                                )
                                            }
                                        />
                                        <button type="submit">Apply</button>
                                    </form>
                                </div>
                            )}
                        </section>
                    )}

                    <MiniCalendar
                        currentDate={currentDate}
                        firstDay={firstDay}
                        showWeekNumbers={showWeekNumbers}
                        onDateSelect={onDateSelect}
                    />

                    <div className="nc-sidebar-section">
                        {/* The whole header row is the collapse target: click
                            anywhere toggles the list. The "+" stops propagation
                            so it only adds a calendar. */}
                        <div
                            className="nc-sidebar-title-row"
                            role="button"
                            tabIndex={0}
                            onClick={() => setCalendarsCollapsed((v) => !v)}
                            onKeyDown={(e) => {
                                if (e.key === "Enter" || e.key === " ") {
                                    e.preventDefault();
                                    setCalendarsCollapsed((v) => !v);
                                }
                            }}
                            title={
                                calendarsCollapsed
                                    ? "Expand calendars"
                                    : "Collapse calendars"
                            }
                        >
                            <span className="nc-sidebar-title-label">
                                <span className="nc-sidebar-title">
                                    Calendars
                                </span>
                                <span
                                    className={`nc-sidebar-title-chevron${
                                        calendarsCollapsed
                                            ? " nc-collapsed"
                                            : ""
                                    }`}
                                >
                                    <ChevronDownIcon size={14} />
                                </span>
                            </span>
                            <span className="nc-sidebar-title-actions">
                                <button
                                    className="nc-sidebar-add-btn"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        setHeaderMenuAnchor(
                                            e.currentTarget.getBoundingClientRect()
                                        );
                                    }}
                                    title="More options"
                                >
                                    <MoreHorizontalIcon />
                                </button>
                                <button
                                    className="nc-sidebar-add-btn"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        onAddCalendar();
                                    }}
                                    title="Add calendar"
                                >
                                    <PlusIcon size={14} />
                                </button>
                            </span>
                        </div>
                        {!calendarsCollapsed && (
                            <div
                                className={`nc-calendar-list${
                                    reorder.dragging ? " nc-reordering" : ""
                                }`}
                            >
                                {calendarSources.map((source, index) => {
                                    const hidden = hiddenCalendars.has(
                                        source.id
                                    );
                                    const online = ONLINE_TYPES.includes(
                                        source.type
                                    );
                                    // Auto calendars wear their own icon in
                                    // place of the solid swatch, same treatment
                                    // as the feed mark: coloured glyph, no fill.
                                    const isAuto = source.type === "auto";
                                    const glyph = online || isAuto;
                                    const isDefault =
                                        source.id === defaultCalendarId;
                                    const isSelected =
                                        source.id === selectedCalendarId;
                                    const dragProps =
                                        reorder.getItemProps(index);
                                    return (
                                        <div
                                            key={source.id}
                                            ref={dragProps.ref}
                                            className={`nc-calendar-item${
                                                hidden
                                                    ? " nc-calendar-hidden"
                                                    : ""
                                            }${
                                                isDefault
                                                    ? " nc-calendar-default"
                                                    : ""
                                            }${
                                                isSelected
                                                    ? " nc-calendar-selected"
                                                    : ""
                                            }${
                                                dragProps.className
                                                    ? " " + dragProps.className
                                                    : ""
                                            }`}
                                            style={
                                                {
                                                    "--nc-cal-color":
                                                        source.color,
                                                    ...dragProps.style,
                                                } as React.CSSProperties
                                            }
                                            onPointerDown={
                                                dragProps.onPointerDown
                                            }
                                            // The whole row opens this calendar's
                                            // event list â€” except the swatch and
                                            // the action buttons, which stop
                                            // propagation. Skipped while renaming,
                                            // and after a drag (which ends here as
                                            // a click) so reordering doesn't also
                                            // open the panel.
                                            onClick={() => {
                                                if (editingId === source.id)
                                                    return;
                                                if (reorder.wasDragged())
                                                    return;
                                                onCalendarClick(source.id);
                                            }}
                                        >
                                            {/* Left control: colored swatch (with
                                            an RSS mark for remote calendars).
                                            Clicking sets this calendar as the
                                            default â€” but only local editable
                                            ones; remote calendars can't be the
                                            default. Visibility is toggled via
                                            the eye icon, not here. */}
                                            <button
                                                type="button"
                                                ref={(el) => {
                                                    swatchRefs.current[
                                                        source.id
                                                    ] = el;
                                                }}
                                                className={`nc-calendar-visibility${
                                                    source.editable
                                                        ? ""
                                                        : " nc-calendar-visibility-static"
                                                }`}
                                                onClick={(e) => {
                                                    // Never open the event list
                                                    // from the swatch.
                                                    e.stopPropagation();
                                                    // Shift-click is the direct
                                                    // shortcut to change the
                                                    // colour. Kept separate from a
                                                    // plain click so changing the
                                                    // colour never also flips the
                                                    // default calendar â€” a
                                                    // double-click used to fire
                                                    // the plain onClick first and
                                                    // reset the default every time.
                                                    if (e.shiftKey) {
                                                        openColorPicker(
                                                            source.id,
                                                            source.color
                                                        );
                                                        return;
                                                    }
                                                    if (source.editable)
                                                        onSetDefaultCalendar(
                                                            source.id
                                                        );
                                                }}
                                                title={
                                                    source.editable
                                                        ? "Set as default (shift-click to change colour)"
                                                        : "Shift-click to change colour"
                                                }
                                            >
                                                <span
                                                    className={`nc-calendar-checkbox${
                                                        glyph
                                                            ? " nc-calendar-feed"
                                                            : ""
                                                    }`}
                                                    style={
                                                        glyph
                                                            ? {
                                                                  color: source.color,
                                                              }
                                                            : {
                                                                  backgroundColor:
                                                                      source.color,
                                                                  borderColor:
                                                                      source.color,
                                                              }
                                                    }
                                                >
                                                    {online && (
                                                        <RssIcon
                                                            size={15}
                                                            maskId={source.id}
                                                        />
                                                    )}
                                                    {isAuto && (
                                                        <ObsidianIcon
                                                            name={
                                                                source.icon ||
                                                                "flag"
                                                            }
                                                            size={15}
                                                        />
                                                    )}
                                                </span>
                                            </button>

                                            {editingId === source.id ? (
                                                <div className="nc-calendar-edit">
                                                    <input
                                                        type="text"
                                                        className="nc-calendar-edit-input"
                                                        value={editName}
                                                        onChange={(e) =>
                                                            setEditName(
                                                                e.target.value
                                                            )
                                                        }
                                                        onKeyDown={(e) => {
                                                            if (
                                                                e.key ===
                                                                "Enter"
                                                            )
                                                                commitRename();
                                                            if (
                                                                e.key ===
                                                                "Escape"
                                                            )
                                                                cancelRename();
                                                        }}
                                                        disabled={renaming}
                                                        autoFocus
                                                    />
                                                    <button
                                                        className="nc-calendar-edit-btn nc-edit-ok"
                                                        onClick={commitRename}
                                                        disabled={renaming}
                                                        title="Save"
                                                    >
                                                        {renaming
                                                            ? "..."
                                                            : "OK"}
                                                    </button>
                                                    <button
                                                        className="nc-calendar-edit-btn nc-edit-cancel"
                                                        onClick={cancelRename}
                                                        disabled={renaming}
                                                        title="Cancel"
                                                    >
                                                        Cancel
                                                    </button>
                                                </div>
                                            ) : (
                                                <>
                                                    <span
                                                        className="nc-calendar-name"
                                                        title={source.name}
                                                    >
                                                        {source.name}
                                                    </span>
                                                    {isDefault && (
                                                        <span className="nc-calendar-default-label">
                                                            Default
                                                        </span>
                                                    )}
                                                    <div className="nc-calendar-actions">
                                                        <button
                                                            type="button"
                                                            className="nc-calendar-action-btn"
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                openMenu(
                                                                    e,
                                                                    source.id
                                                                );
                                                            }}
                                                            title="More options"
                                                        >
                                                            <MoreHorizontalIcon />
                                                        </button>
                                                        <button
                                                            type="button"
                                                            className="nc-calendar-action-btn"
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                onToggleCalendar(
                                                                    source.id
                                                                );
                                                            }}
                                                            title={
                                                                hidden
                                                                    ? "Show"
                                                                    : "Hide"
                                                            }
                                                        >
                                                            {hidden ? (
                                                                <EyeOffIcon />
                                                            ) : (
                                                                <EyeIcon />
                                                            )}
                                                        </button>
                                                    </div>
                                                </>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                </>
            )}

            {menuSource && menuAnchor && (
                <CalendarItemMenu
                    items={buildMenuItems(menuSource)}
                    anchorRect={menuAnchor}
                    onClose={() => setMenuId(null)}
                />
            )}

            {headerMenuAnchor && (
                <CalendarItemMenu
                    items={[
                        {
                            key: "open-root",
                            label: "Open root folder",
                            icon: <FolderIcon />,
                            onClick: onOpenRootFolder,
                        },
                    ]}
                    anchorRect={headerMenuAnchor}
                    onClose={() => setHeaderMenuAnchor(null)}
                />
            )}

            <div className="nc-sidebar-footer">
                <button
                    type="button"
                    className="nc-sidebar-help-btn"
                    title="Keyboard shortcuts"
                    aria-label="Keyboard shortcuts"
                    onClick={(event) =>
                        setShortcutsAnchor(
                            shortcutsAnchor
                                ? null
                                : event.currentTarget.getBoundingClientRect()
                        )
                    }
                >
                    <CircleHelpIcon size={16} />
                </button>
            </div>

            {shortcutsAnchor && (
                <ShortcutsPanel
                    anchorRect={shortcutsAnchor}
                    onClose={() => setShortcutsAnchor(null)}
                />
            )}

            {colorPicker && (
                <ColorPicker
                    color={colorPicker.color}
                    anchorRect={colorPicker.rect}
                    onChange={(hex) => onColorChange(colorPicker.id, hex)}
                    onClose={() => setColorPicker(null)}
                />
            )}
        </div>
    );
}
